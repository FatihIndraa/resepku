<?php $__env->startSection('konten'); ?>
    <section class="py-4 py-xl-5">
        <div class="container">
            <div class="mb-3">
                <h1 class="mb-5"><?php echo e($post->title); ?></h1>

                <p>Author: <?php echo e($post->user->name); ?></p>
                <p>Category: <a href="<?php echo e(route('detail', $post->category->slug)); ?>"><?php echo e($post->category->name); ?></a></p>


                <?php echo $post->body; ?>


                <a href="/">Back to Home</a>
            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\OneDrive\Documents\GitHub\cofeeshop\laravel\resources\views/post.blade.php ENDPATH**/ ?>