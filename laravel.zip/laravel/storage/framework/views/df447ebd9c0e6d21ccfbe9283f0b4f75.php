<?php $__env->startSection('konten'); ?>
    <section class="py-4 py-xl-5">
        <div class="container">
            <div class="text-white bg-dark border-0 border rounded p-4 p-md-5 mb-xxl-4">
                <?php if(auth()->guard()->check()): ?>
                    <h2 class="fw-bold text-white mb-3">Haloooo, <?php echo e(auth()->user()->name); ?></h2>
                    <p class="mb-4">hayoo, pasti lagi mau cari <?php echo e($category->name); ?></p>
                </div>
            </div>
            <div class="container py-4 py-xl-5">
                <div class="row mb-5" style="padding-bottom:0px;font-size:20px;">
                    <div class="col-md-8 col-xl-6 col-xxl-5 text-center mx-auto">
                        <h2>Menu</h2>
                        <p class="w-lg-50">Berikut adalah berbagai macam resep menu yang ada pada Resepku.</p>
                    </div>
                </div>
            <?php else: ?>
                <h2 class="fw-bold text-white mb-3">Selamat Datang di Resepku</h2>
                <p class="mb-4">Mau masak makanan apa hari ini? Yuk coba lihat berbagai macam resep yang ada.</p>
                <a href="/login" class="btn btn-primary text-decoration-none">Login dulu yuk</a>
            </div>
            </div>
            <div class="container py-4 py-xl-5">
                <div class="row mb-5" style="padding-bottom:0px;font-size:20px;">
                    <div class="col-md-8 col-xl-6 col-xxl-5 text-center mx-auto">
                        <h2>Menu <?php echo e($category->name); ?></h2>
                        <p class="w-lg-50">Berikut adalah berbagai macam resep menu makanan yang ada pada Resepku.</p>
                    </div>
                </div>
            <?php endif; ?>
            <?php if($posts->count()): ?>
                <div class="container">
                    <div class="row">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="card">
                                    <img src="..." class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($post->title); ?></h5>
                                        <p>
                                            <small class="text-muted">
                                                By: <?php echo e($post->user->name); ?>

                                                <?php echo e($post->updated_at->diffForHumans()); ?>

                                            </small>
                                        </p>
                                        <p class="card-text"><?php echo e($post->excerpt); ?></p>
                                        <a href="<?php echo e(route('post', $post)); ?>" class="btn btn-primary">Lihat Selengkapnya</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php else: ?>
                <p class="text-center fs-4">No Post Found</p>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\OneDrive\Documents\GitHub\cofeeshop\laravel\resources\views/detail.blade.php ENDPATH**/ ?>