

<?php $__env->startSection('konten'); ?>
    <article>
        <h2><a href="/posts/ <?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h2>
        <p><?php echo e($post->body); ?></p>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\OneDrive\Documents\GitHub\cofeeshop\laravel\resources\views/posts.blade.php ENDPATH**/ ?>